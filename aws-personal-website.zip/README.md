# AWS Personal Website

This is a **beginner AWS project** to host a static website using **Amazon S3**.

## Steps to Deploy

1. Create an S3 bucket in AWS.
2. Enable **Static Website Hosting**.
3. Upload the files from this repository.
4. Make the bucket public.
5. Optionally, use CloudFront for faster delivery and Route 53 for a custom domain.

## Project Structure

- `index.html` – Homepage
- `about.html` – About page
- `contact.html` – Contact page
- `css/style.css` – Stylesheet
- `js/script.js` – JavaScript file